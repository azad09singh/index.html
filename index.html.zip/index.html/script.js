const ESP8266_IP = "192.168.84.147"; // Replace with your ESP8266 IP

// Initialize DOM elements
const powerButton = document.getElementById('power');
const colorPicker = document.getElementById('colorPicker');
const currentColor = document.getElementById('currentColor');
const randomColorButton = document.getElementById('randomColor');
const brightnessSlider = document.getElementById('brightness');
const effectsDropdown = document.getElementById('effects');
const themeSelect = document.getElementById('themeSelect');
const defaultThemeButton = document.getElementById('defaultTheme');
const timerInput = document.getElementById('timer');
const setTimerButton = document.getElementById('setTimer');

// Wi-Fi Modal Elements
const settingsIcon = document.getElementById('settingsIcon');
const wifiModal = document.getElementById('wifiModal');
const closeModal = document.getElementsByClassName('close')[0];

// Store the current color and effect settings
let selectedColor = "#ffffff"; // Default color (White)
let selectedEffect = 0; // Default effect (Solid)

async function fetchState() {
    try {
        const response = await fetch(`http://${ESP8266_IP}/json/state`);
        const data = await response.json();
        updateUI(data);
    } catch (error) {
        console.error("Error fetching state:", error);
    }
}

function updateUI(state) {
    powerButton.textContent = state.on ? "Turn Off" : "Turn On";
    brightnessSlider.value = state.bri;
    const [r, g, b] = state.seg[0].col[0];
    colorPicker.value = rgbToHex(r, g, b);
    currentColor.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
    effectsDropdown.value = state.seg[0].fx;
}

// Convert RGB to HEX
function rgbToHex(r, g, b) {
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// Send updates to the WLED API
async function sendUpdate(body) {
    try {
        await fetch(`http://${ESP8266_IP}/json/state`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    } catch (error) {
        console.error("Error sending update:", error);
    }
}

// Power button handler
powerButton.addEventListener('click', () => {
    const isOn = powerButton.textContent === "Turn Off";
    sendUpdate({ on: !isOn });
    powerButton.textContent = isOn ? "Turn On" : "Turn Off";
});

// Color picker handler
colorPicker.addEventListener('input', (event) => {
    selectedColor = event.target.value;
    currentColor.style.backgroundColor = selectedColor;
    updateColor(); // Apply selected color
});

// Random color button handler
randomColorButton.addEventListener('click', () => {
    const randomColor = [
        Math.floor(Math.random() * 256),
        Math.floor(Math.random() * 256),
        Math.floor(Math.random() * 256),
    ];
    selectedColor = rgbToHex(...randomColor);
    colorPicker.value = selectedColor;
    currentColor.style.backgroundColor = selectedColor;
    updateColor(); // Apply random color
});

// Brightness slider handler
brightnessSlider.addEventListener('input', (event) => {
    sendUpdate({ bri: parseInt(event.target.value, 10) });
});

// Populate effects dropdown with effects list
function populateEffects() {
    const effects = [
        "Solid", "Blink", "Breathe", "Wipe", "Scan", "Theater Chase", "Rainbow", "Fire", "Twinkle", "Wave",
        "Color Loop", "Meteor", "Color Waves", "Rainbow Cycle", "Scanner", "Music", "Random Color", "Shimmer", 
        "Ripple", "Breathing", "Dynamic", "Flashing", "Fireworks", "Comet", "Running Lights", "Lightning", 
        "Pulse", "Twinklefade", "Candle", "Lightning", "Breath", "Flicker", "Strobe", "Dawn", "Galaxy", 
        "ColorFlow", "Firefly", "Stream", "Snowfall", "Heartbeat", "Morse", "Bar", "Spiral", "Pacman", 
        "Matrix", "Pulse Wave", "Rainbow Wave", "Tornado", "Chase", "Bounce", "Cascade", "Ripple Fade"
    ];
    effects.forEach((effect, index) => {
        const option = document.createElement('option');
        option.value = index;
        option.textContent = effect;
        effectsDropdown.appendChild(option);
    });
}

// Handle effect selection
effectsDropdown.addEventListener('change', (event) => {
    selectedEffect = parseInt(event.target.value, 10);
    applyEffect(); // Apply selected effect
});

// Apply the selected effect
function applyEffect() {
    const effectData = { seg: [{ fx: selectedEffect, col: [hexToRgb(selectedColor)] }] };
    sendUpdate(effectData);
}

// Predefined themes with colors
const colorThemes = [
    ["#ffffff", "Warm White"], ["#00f0ff", "Cool Blue"], ["#ff6347", "Tomato"], ["#ff4500", "Orange Red"], 
    ["#32cd32", "Lime Green"], ["#ff1493", "Deep Pink"], ["#8a2be2", "Blue Violet"], ["#20b2aa", "Light Sea Green"], 
    ["#000080", "Navy"], ["#b22222", "Firebrick"], ["#ff0000", "Red"], ["#7fff00", "Chartreuse"], 
    ["#d2691e", "Chocolate"], ["#00ff00", "Lime"], ["#0000ff", "Blue"], ["#ff00ff", "Magenta"], 
    ["#f0e68c", "Khaki"], ["#b0c4de", "Light Steel Blue"], ["#98fb98", "Pale Green"], ["#dda0dd", "Plum"], 
    ["#c71585", "Medium Violet Red"]
];

// Populate the theme dropdown
colorThemes.forEach((theme, index) => {
    const option = document.createElement('option');
    option.value = theme[0];
    option.textContent = theme[1];
    themeSelect.appendChild(option);
});

// Apply the selected color theme
themeSelect.addEventListener('change', (event) => {
    selectedColor = event.target.value; // Store selected theme color
    updateColor(); // Apply the selected theme color
});

// Default theme button handler
defaultThemeButton.addEventListener('click', () => {
    selectedColor = "#ffffff"; // Reset to default theme (white)
    updateColor(); // Apply default color
});

// Update LED color based on the selected color
function updateColor() {
    sendUpdate({ seg: [{ col: [hexToRgb(selectedColor)] }] });
    colorPicker.value = selectedColor;
    currentColor.style.backgroundColor = selectedColor;
}

// Convert HEX to RGB
function hexToRgb(hex) {
    const bigint = parseInt(hex.slice(1), 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;
    return [r, g, b];
}

// Timer handler
setTimerButton.addEventListener('click', () => {
    const timerTime = timerInput.value;
    if (timerTime) {
        const [hour, minute] = timerTime.split(':').map(Number);
        const now = new Date();
        const targetTime = new Date(now.setHours(hour, minute, 0, 0));

        const remainingTime = targetTime - new Date();
        if (remainingTime > 0) {
            setTimeout(() => {
                sendUpdate({ on: false }); // Turn off LED after the timer
            }, remainingTime);
        }
    }
});

// Wi-Fi Setup Modal Logic
settingsIcon.addEventListener('click', () => {
    wifiModal.style.display = "block";
});

closeModal.addEventListener('click', () => {
    wifiModal.style.display = "none";
});

window.addEventListener('click', (event) => {
    if (event.target === wifiModal) {
        wifiModal.style.display = "none";
    }
});

// Initialize effects dropdown and UI
populateEffects();
